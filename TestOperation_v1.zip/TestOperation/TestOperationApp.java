public class TestOperationApp {
    public static void main(String[] args) {
        System.out.println("Running TestOperationApp...");
        System.out.println("\nRunning Test01PlayerBasic...\n");
        Test01PlayerBasic.main((String[]) null);
        System.out.println("\nRunning Test02PlayerExceptions...\n");
        Test02PlayerExceptions.main((String[]) null);
    }
}